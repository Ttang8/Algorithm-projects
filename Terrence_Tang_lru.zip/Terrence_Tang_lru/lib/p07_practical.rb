require_relative 'p05_hash_map'

def can_string_be_palindrome?(string)
  hsh = HashMap.new
  length = string.chars.length
  string.chars.each do |ch|
    if hsh[ch] == nil
      hsh[ch] = 0
    end
    hsh[ch] = hsh[ch] + 1
  end
  if length.even?
    hsh.each do |key, val|
      return false if val.odd?
    end
    return true
  end
  if length.odd?
    odd = 0
    even = 0
    hsh.each do |key, val|
      odd += 1 if val.odd?
      even += 1 if val.even?
    end
    return true if odd == 1
    return false
  end
end
