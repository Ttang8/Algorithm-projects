class Node
  attr_accessor :key, :val, :next, :prev

  def initialize(key = nil, val = nil)
    @key = key
    @val = val
    @next = nil
    @prev = nil
  end

  def to_s
    "#{@key}: #{@val}"
  end

  def remove
    @prev.next = @next
    @next.prev = @prev
    # optional but useful, connects previous node to next node
    # and removes self from list.
  end
end

class LinkedList
  include Enumerable
  def initialize
    @head = Node.new
    @tail = Node.new
    @head.next = @tail
    @tail.prev = @head
  end

  def [](i)
    self.each_with_index { |node, j| return node if i == j }
    nil
  end

  def first
    @head.next unless empty?
  end

  def last
    @tail.prev unless empty?
  end

  def empty?
    return true if @head.next == @tail
    false
  end

  def get(key)
    return nil if empty?
    self.each do |node|
      return node.val if node.key == key
    end
    nil
  end

  def include?(key)
    return nil if empty?
    self.each do |node|
      return true if node.key == key
    end
    false
  end

  def append(key, val)
    if include?(key)
      update(key, val)
    else
      new_node = Node.new(key, val)
      new_node.prev = @tail.prev
      new_node.next = @tail
      @tail.prev.next = new_node
      @tail.prev = new_node
    end
  end

  def update(key, val)
    if empty?
      return nil
    else
      self.each do |node|
        if node.key == key
          node.val = val
        end
      end
    end
  end

  def remove(key)
    self.each do |node|
      if node.key == key
        node.remove
      end
    end
  end

  def each(&prc)
    current_node = @head.next
    until current_node.key == nil
      prc.call(current_node)
      current_node = current_node.next
    end
  end

  # uncomment when you have `each` working and `Enumerable` included
  def to_s
    inject([]) { |acc, node| acc << "[#{node.key}, #{node.val}]" }.join(", ")
  end
end
